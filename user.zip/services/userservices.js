
exports.getExpenses=(req,res)=>{
    return req.user.getExpenses();
}

